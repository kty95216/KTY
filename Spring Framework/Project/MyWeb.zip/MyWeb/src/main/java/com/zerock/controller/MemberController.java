package com.zerock.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zerock.member.command.MemberVO;
import com.zerock.member.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	//	create table member(
	//	    id varchar(50) primary key,
	//	    pw varchar(50),
	//	    name varchar(50),
	//	    regdate datetime default current_timestamp
	//	);

	@Autowired
	private MemberService member;

	//회원가입 화면처리
	@RequestMapping("/join")
	public String join() {
		return "member/join";
	}
	//로그인 화면처리
	@RequestMapping("/login")
	public String login() {
		return "member/login";
	}

	//ajax요청 받기
	@RequestMapping("/checkId")
	@ResponseBody //리턴을 view리졸버로 전달하지 않고, 해당메서드를 호출한 곳으로 결과를 반환
	public int checkId(@RequestParam("id") String id) {

		int result = member.idCheck(id);
		System.out.println("아이디 개수:" + result);

		return result;
	}

	//join 폼 처리
	@RequestMapping("/joinForm")
	public String joinForm(MemberVO vo, RedirectAttributes RA) {

		int result = member.join(vo);

		if(result == 1) { //1을 리턴받았다는 것은 insert성공
			RA.addFlashAttribute("msg", "회원가입에 성공했습니다");
		} else { //insert실패
			RA.addFlashAttribute("msg", "회원가입에 실패했습니다");
		}
		return "redirect:/member/login"; //login컨트롤러로 다시 타게하는 로직
	}

	//login 폼 처리(폼 처리후 header.jsp의 131번 라인 JSTL구문으로 로그인 처리 확인하세요)
	@RequestMapping("/loginForm")
	public String loginForm(MemberVO vo, HttpSession session, RedirectAttributes RA) {

		int result = member.login(vo);


		if(result == 1) { //1개의 카운트가 나왔다는 것은 로그인 성공
			session.setAttribute("user_id", vo.getId()); //세션에 아이디 저장
			return "redirect:/"; //Home컨트롤러의 맵핑으로
		} else { //로그인 실패
			RA.addFlashAttribute("msg", "아이디 비밀번호를 확인하실래요?"); //1회성 데이터에 msg저장
			return "redirect:/member/login";
		}

	}
	//로그아웃
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();

		return "redirect:/";
	}
	
	
	//컨트롤러 작성후에 util패키지의 Boardinterceptor로 로그인하지 않은 회원의 게시판 사용불가 확인  






}
