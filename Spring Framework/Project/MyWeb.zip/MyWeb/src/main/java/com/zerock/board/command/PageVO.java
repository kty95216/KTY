package com.zerock.board.command;

public class PageVO {

	//Criteria 기준, 전체게시글 수를 전달받아서 화면에 그려질 페이징 번호를 계산하는 클래스
	
	//1. total : 게시글 전체 개수
	//2. realEnd : 게시판의 실제 마지막 번호.
	//3. endPage : 게시판에 보여질 마지막 페이지 번호
	//4. startPage : 게시판에 보여질 시작 페이지 번호
	//5. prev : 이전 페이지 버튼 활성화 여부
	//6. next : 다음 페이지 활성화 여부
	
	private int startPage;
	private int endPage;
	
	private boolean prev;
	private boolean next;
	
	private int total;
	private Criteria cri;
	
	//생성자
	public PageVO(int total, Criteria cri) {
		this.total = total;
		this.cri = cri;
		
		//화면에 보여질 끝 페이지
		//현재 조회하는 페이지가 1번 -> 화면에 보여질 끝 페이지 10
		//현재 조회하는 페이지가 15번 -> 화면에 보여질 끝 페이지 20
		//공식: (int)Math.ceil(현재 조회하는 페이지 번호 / 10.0) * 10;
		this.endPage = (int)Math.ceil(cri.getPageNum() / 10.0) * 10;
		
		//시작 페이지
		//공식: endPage - 한번에 보여질 페이지 개수 + 1
		this.startPage = endPage - 9;
		
		//실제 마지막 페이지 번호
		//만약 총 게시물이 52개 밖에 없다면? -> 페이지 번호 6번 까지 표시되어야 함
		//만약 총 게시물이 105개 라면 ? -> 페이지 번호는 11번 까지 표시되어야 함
		//11번 클릭시 -> endPage의 공식 -> 11,12,13....20 이 보이게 됨
		
		//공식: (int)Math.ceil( 전체 게시글 수/몇개의 페이지를 보여줄건지)
		int realEnd = (int)Math.ceil( total / (double)cri.getCount() );
		
		//ex: 131개 게시물
		//1번 페이지 클릭시 -> endPage의 공식 = 10, realEnd = 14
		//실제 화면에 보여져야하는 번호 = 10	
		//11번 페이지 클릭시 -> endPage의 공식 = 20, realEnd = 14
		//실제 화면에 보여져야하는 번호 = 14
		
		//ex: 51개 게시물
		//1번 페이지 클릭시 -> endPage의 공식 = 10, realEnd = 6
		//실제 화면에 보여져야하는 번호 = 6
		
		//결론 -> endPage > realEnd 라면 realEnd를 보여주면 됨.
		if( this.endPage > realEnd) {
			this.endPage = realEnd;
		}
		
		//이전 버튼 활성화 여부
		//startPage는 1, 11, 21... 101로 표시
		//공식 : startPage > 1  이라면 버튼 활성화
		this.prev = this.startPage > 1;
		
		//다음 버튼 활성화 여부 ( realEnd 가 endPage) 보다 큰 경우만 활성화
		this.next = realEnd > this.endPage;
		
		System.out.println("[endPage]" + endPage);
		System.out.println("[startPage]" + startPage);
	}

	//이후에 게터/세터  ---> list요청에 대한 변경
	
	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public boolean isPrev() {
		return prev;
	}

	public void setPrev(boolean prev) {
		this.prev = prev;
	}

	public boolean isNext() {
		return next;
	}

	public void setNext(boolean next) {
		this.next = next;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public Criteria getCri() {
		return cri;
	}

	public void setCri(Criteria cri) {
		this.cri = cri;
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
