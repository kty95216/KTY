package com.zerock.board.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zerock.board.command.BoardVO;
import com.zerock.board.command.Criteria;
import com.zerock.board.mapper.BoardMapper;

//@Service = 자동생성명령, ("이름") 사용할 이름을 강제지정
@Service("service")
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardMapper mapper;
	
	@Override
	public void regist(BoardVO vo) {
		
		//화면에서 넘어온 writer, content, title 출력
		//System.out.println(vo.getWriter());
		//System.out.println(vo.getContent());
		//System.out.println(vo.getTitle());
		
		//1.BoardMapper.xml로 구현체 생성
		//2.xml설정 (root-xml 마이바티스스캔)
		//3.namespace경로 설정
		//4.insert구문으로 board테이블에 insert
		//5. sql = insert into tbl_board(writer, content, title) values(?,?,?);
		//6. 호출	
		mapper.insertBoard(vo);
		
		
	}
	//게시글 가져오기
//	@Override
//	public ArrayList<BoardVO> getList() {
//	
//		ArrayList<BoardVO> list = mapper.getList();
//		
//		return list;
//	}
	
	//페이징 게시글 가져오기
	public ArrayList<BoardVO> getList(Criteria cri) {
	
		ArrayList<BoardVO> list = mapper.getList(cri);
		
		return list;
	}
	
	//전체 게시글 수를 구하는 메서드
	public int getTotal() {
		
		int total = mapper.getTotal();
		
		return total;
	}
	
	
	
	@Override
	public BoardVO getContent(int num) {
		
		BoardVO vo = mapper.getContent(num);
		
		return vo;
	}

	@Override
	public void update(BoardVO vo) {
		
		mapper.boardUpdate(vo);
		
	}

	@Override
	public void delete(int num) {
		
		boolean bool = mapper.boardDelete(num);
		System.out.println("성공?" + bool);
	}


	
	
}








