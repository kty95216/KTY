package com.zerock.board.service;

import java.util.ArrayList;

import com.zerock.board.command.BoardVO;
import com.zerock.board.command.Criteria;

public interface BoardService {

	//public ArrayList<BoardVO> getList(); //게시글 목록 가져오기
	public ArrayList<BoardVO> getList(Criteria cri); //페이징 게시글 목록 가져오기
	public int getTotal(); //전체 게시글 수를 구하는 메서드
	
	
	public void regist(BoardVO vo); //게시글 등록
	public BoardVO getContent(int num); //상세보기 목록 가져오기
	
	public void update(BoardVO vo); //수정완료 버튼
	public void delete(int num); //삭제 기능
}
