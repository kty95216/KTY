package com.zerock.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class TestLoginInterceptor extends HandlerInterceptorAdapter{

	//1. 스프링에서 제공하는 HandlerInteceptorAdepter를 상속받습니다.
	//2. alt + shift +s 로 일반적으로 3가지의 메서드를 오버라이딩 해서 사용합니다.
	//3. 인터셉터를 설정했으면, 스프링 설정파일에 <interceptor> 태그를 이용해서 맵핑 설정을 합니다.
	
	//컨트롤러 실행하기 전에 요청을 가로채서 먼저 검사.
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
	
		//세션을 얻는 방법
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("test_id");
		
		if( id == null) {
			response.sendRedirect("/MyWeb/session/loginPage");
			return false; //return false의 의미는 메서드 실행후 Controller를 실행하지 않음
		} else {
			return true; //return true는 메서드 실행후 Controller를 실행함
		}
		
		
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		super.afterCompletion(request, response, handler, ex);
	}

	
	
}
