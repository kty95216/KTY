package com.zerock.board.command;

public class Criteria {

	//페이징 쿼리 : select * from tbl_board order by num desc limit 0, 10;
	//페이징 기준 클래스(쿼리문에 전달될 값을 지정하는 클래스)
	
	private int pageNum; //현재 조회하고 있는 페이지번호
	private int count;   //몇개의 데이터를 보여줄건가
	
	//생성자(최초에 게시판에 진입할 때 기본값을 1번 페이지의 10개의 데이터를 세팅
	public Criteria() {
		this.pageNum = 1;
		this.count = 10;
	}
	//생성자(사용자가 게시판 번호를 클릭했을 때 실행될 생성자)
	public Criteria(int pageNum, int count) {
		this.pageNum = pageNum;
		this.count = count;
	}
	
	//limit구문에서 시작위치를 지정할때 사용하는 메서드 생성
	//limit x, count 구문에 전달될 x를 구하는 메서드 
	public int getPageStart() {
		/* 1번 페이지를 클릭하면 limit 0, 10
		 * 2번 페이지를 클릭하면 limit 10, 10
		 * 3번 페이지를 클릭하면 limit 20, 10
		 */
		//return (pageNum -1) * 10;
		return (pageNum -1) * count;
	}
	

	//아래 게터 세터-->리스트 요청 변경 
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
	
	
	
	
}
