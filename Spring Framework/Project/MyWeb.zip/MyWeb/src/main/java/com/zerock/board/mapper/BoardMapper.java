package com.zerock.board.mapper;

import java.util.ArrayList;

import com.zerock.board.command.BoardVO;
import com.zerock.board.command.Criteria;

public interface BoardMapper {

	//public ArrayList<BoardVO> getList(); //모든 게시글 가져오기
	public ArrayList<BoardVO> getList(Criteria cri); //페이징 게시글 가져오기
	public int getTotal(); //전체 게시글을 조회하는 메서드
	
	
	public void insertBoard(BoardVO vo);//게시글 등록
	public BoardVO getContent(int num); //상세보기 목록 가져오기
	public void boardUpdate(BoardVO vo); //수정완료 버튼
	
	public boolean boardDelete(int num); //삭제 기능
}
