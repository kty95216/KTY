package com.zerock.util;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.zerock.controller.HomeController;

//@Controller, @Service, @Repository, @Component.......
@Component //bean을 자동 생성명령
@Aspect //AOP클래스를 의미
public class LogAdvice {
	
	//해당기능은 로그를 출력하는 기능
	/* log4j.xml의 로그 레벨 설정
	<logger name="com.zerock.util">
		<level value="info" />
	</logger>
	*/
	private static final Logger log = LoggerFactory.getLogger(LogAdvice.class);
	
	
//	@Before("execution(* com.zerock.board.service.BoardServiceImpl.*(..))")
//	public void beforeLog() {
//		System.out.println("----before----");
//	}
//	
//	@After("execution(* com.zerock.board.service.BoardServiceImpl.*(..))")
//	public void afterLog() {
//		System.out.println("----after----");
//	}
	//---->스프링 설정파일에 AOP설정 추가
	
	@Around("execution(* com.zerock.board.service.BoardServiceImpl.*(..))")
	public Object arountLog(ProceedingJoinPoint jp) {
		
		long start = System.currentTimeMillis();
		
		Object result = null;
		try {
			result = jp.proceed(); //해당 메서드를 만나면 타겟이 되는 메서드가 실행
		
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		long end = System.currentTimeMillis();
//		System.out.println("메서드 수행에 걸린시간:" + (end - start));
//		System.out.println("적용클래스:" + jp.getTarget());
//		System.out.println("적용파라미터:" + Arrays.toString(jp.getArgs()));
		log.info("메서드 수행에 걸린시간:" + (end - start));
		log.info("적용클래스:" + jp.getTarget());
		log.info("적용파라미터:" + Arrays.toString(jp.getArgs()));
		
		
		return result;
	}
	
	
	
	
}
