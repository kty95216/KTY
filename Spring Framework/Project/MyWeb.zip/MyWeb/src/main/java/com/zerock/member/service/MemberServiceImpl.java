package com.zerock.member.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zerock.member.command.MemberVO;
import com.zerock.member.mapper.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService{

	@Autowired
	private MemberMapper mapper;
	//아이디 중복체크
	@Override
	public int idCheck(String id) {

		int result = mapper.idCheck(id);

		return result;
	}
	//회원 가입
	@Override
	public int join(MemberVO vo) {

		int result = mapper.join(vo);
		System.out.println("성공실패?" + result);

		return result;
	}

	//로그인
	@Override
	public int login(MemberVO vo) {

		int result = mapper.login(vo);
		System.out.println("성공실패?:" + result);

		return result;
	}

}
